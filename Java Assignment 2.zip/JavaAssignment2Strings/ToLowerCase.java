import java.util.Scanner;

public class ToLowerCase {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        String s1 = sc.nextLine();
        String s1lower=s1.toLowerCase();
        System.out.println(s1lower);
    }
}
//this is java
//        this is java
