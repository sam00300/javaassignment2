public class Join {
    public static void main(String[] args) {
        String joinString1=String.join("-","welcome","to","javatpoint");
        System.out.println(joinString1);
    }
}
