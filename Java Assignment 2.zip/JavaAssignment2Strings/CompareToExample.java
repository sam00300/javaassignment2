

 public class CompareToExample{
    public static void main(String args[]){
        String s1="hello";
        String s2="";
        String s3="me";
        System.out.println(s1.compareTo(s2));
        System.out.println(s2.compareTo(s3));
    }}

//Output

//5
//-2
