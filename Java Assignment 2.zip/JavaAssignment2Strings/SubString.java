import java.util.Scanner;

public class SubString {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        String s1 = sc.nextLine();
        System.out.println(s1.substring(2,4));//returns va
        System.out.println(s1.substring(2));//returns vatpoint
    }
}
//this is java
//        is
//        is is java
